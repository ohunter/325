#include "types.h"
#include "stat.h"
#include "user.h"

int main(){

        int pid = getpid();

        printf(1, "Unmodified Value\n");
        printf(1, "Current nice value: %d\n", get_priority(pid));

        set_priority(pid, 4231);

        printf(1, "Out of Bounds Value\n");
        printf(1, "Current nice value: %d\n", get_priority(pid));

        set_priority(pid, 21);

        printf(1, "Inside of Bounds Value\n");
        printf(1, "Current nice value: %d\n", get_priority(pid));

        return 0;
}