struct lock_t {
        int init;
        struct proc* cur;
};