Q1: 

Bytes per block:        512
Number of blocks:       12 + 128 + 128*128
Max File Fize:          8460288 Bytes ~ 8.46MB

Q2:

Bytes per block:        512
Number of blocks:       12 + 128 + 128*128 + 128*128*128
Max File Fize:          1082202112 Bytes ~ 1.08GB


Makefile        :       Implemented changes mentioned in lab
param.h         :       Implemented changes mentioned in lab
fs.h            :       Implement larger file size
file.h          :       Implement larger file size
fs.c            :       Implement changes to accomodate for larger file size